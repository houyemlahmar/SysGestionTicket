﻿using System.Windows.Forms;

namespace SysGestionTicket
{
    public partial class formAdmin : Form
    {
        public formAdmin()
        {
            InitializeComponent();
        }
    }
}
